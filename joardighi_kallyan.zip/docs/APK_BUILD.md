# APK বানানোর নিয়ম (কম্পিউটারে Flutter ছাড়াই, GitHub দিয়ে)

1. https://github.com এ একাউন্ট খুলুন → **New repository** → নাম `joardighi-kallyan` → **Private** → Create।
2. **uploading an existing file** লিংকে ক্লিক করে এই ZIP-এর ভেতরের সব ফাইল/ফোল্ডার আপলোড করুন (`.github` ফোল্ডারসহ) → Commit।
3. Firebase Console → Project settings → Your apps → **Add app → Android**।
   Package name: `app.joardighi.joardighi_kallyan` → Register (বাকি ধাপ Skip)।
4. ওই অ্যাপের কনফিগ থেকে চারটি মান নিয়ে GitHub-এ `lib/firebase_options.dart` ফাইল এডিট করুন (পেন্সিল আইকন): apiKey, appId, messagingSenderId (Project number), projectId।
5. Firebase Authentication (Email/Password), Firestore, Rules ও প্রথম Super Admin — `docs/SETUP.md`-এর ১, ৪, ৫ নম্বর ধাপ।
6. GitHub → **Actions → Build APK → Run workflow**। ৫–১০ মিনিট পর রান শেষে নিচে **Artifacts → joardighi-kallyan-apk** ডাউনলোড করুন (ZIP-এর ভেতরে `app-release.apk`)।
7. ফোনে APK ইনস্টল করুন (Unknown sources অনুমতি দিতে হবে)।

লাল ❌ এলে ব্যর্থ রানে ক্লিক করে এরর লগ কপি করে আমাকে পাঠান।
এই APK ডিবাগ-কি দিয়ে সাইন করা, সদস্যদের মধ্যে বিতরণের জন্য চলবে। প্লে স্টোরের জন্য আলাদা keystore লাগবে।
