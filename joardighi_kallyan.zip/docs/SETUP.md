# Firebase সেটআপ গাইড (Spark / ফ্রি প্ল্যান)

## ১. প্রজেক্ট তৈরি
1. https://console.firebase.google.com → **Add project** → নাম: `joardighi-kallyan` (Analytics বন্ধ রাখা যায়)।
2. **Build → Authentication → Get started → Email/Password** চালু করুন।
3. **Build → Firestore Database → Create database** → Production mode → লোকেশন `asia-south1` (মুম্বাই) বা `asia-southeast1`। লোকেশন পরে বদলানো যায় না।
4. Storage: নতুন প্রজেক্টে ফ্রিতে না পেলে বাদ দিন; অ্যাপ রসিদ সংকুচিত করে Firestore-এ রাখবে।

## ২. কম্পিউটারে টুল
```
flutter doctor
npm i -g firebase-tools
dart pub global activate flutterfire_cli
firebase login
```

## ৩. অ্যাপের সাথে সংযোগ
প্রজেক্ট ফোল্ডারে:
```
flutter create --org app.joardighi --project-name joardighi_kallyan .
flutter pub get
flutterfire configure     # joardighi-kallyan বেছে নিন, Android টিক দিন
```
এতে `lib/firebase_options.dart` ও `android/app/google-services.json` তৈরি হবে।
> `flutter create .` আমাদের `pubspec.yaml` বদলে দিলে আমার দেওয়া ফাইলটি আবার বসান।

## ৪. সিকিউরিটি রুলস
```
firebase init firestore    # বিদ্যমান firestore.rules ওভাররাইট করবেন না
firebase deploy --only firestore:rules
```

## ৫. প্রথম Super Admin (একবারই, হাতে)
1. Console → Authentication → **Add user**: ইমেইল `jpks-admin@joardighi.app`, শক্ত পাসওয়ার্ড। **UID কপি করুন।**
2. Firestore → `users` কালেকশন → ডকুমেন্ট ID = ওই UID, ফিল্ড:
   - `userId` (string): `JPKS-ADMIN`
   - `role` (string): `super_admin`
   - `active` (boolean): `true`
   - `mustChangePassword` (boolean): `true`
   - `memberId` (string): ফাঁকা বা আপনার সদস্য আইডি
3. অ্যাপে `JPKS-ADMIN` দিয়ে লগইন করুন।

## ৬. সদস্য আপলোড
`assets/members_seed.json`-এ ৫৮ জন (JPKS-001…058)। ধাপ ৩-এ Super Admin-এর "সদস্য ইমপোর্ট" বাটন এটি Firestore-এ বসাবে। কেউ মার্জ হবে না।

## ৭. জেনে রাখুন
- **পাসওয়ার্ড রিসেট:** লগইন ইমেইল আসল নয় (`@joardighi.app`), তাই ইমেইলে রিসেট লিংক যায় না। সদস্য সেটিংসে আসল ইমেইল যুক্ত ও যাচাই করলে তখন থেকে ইমেইল রিসেট কাজ করবে। না থাকলে Admin পুরোনো একাউন্ট নিষ্ক্রিয় করে নতুন সাফিক্স-আইডি (যেমন `JPKS-012A`) দিয়ে নতুন একাউন্ট দেবে। Spark-এ Admin অন্যের পাসওয়ার্ড সরাসরি বদলাতে পারে না।
- **অনুমোদন ধারা:** Treasurer লেনদেন `pending` হিসেবে তোলেন; শুধু Super Admin অনুমোদন করলে বকেয়া ও ব্যালেন্স হালনাগাদ হয়।
- **ফন্ট:** Google Fonts থেকে `NotoSansBengali-Regular.ttf` ও `-Bold.ttf` নিয়ে `assets/fonts/`-এ রাখুন। `assets/logo.png`-এ লোগো দিন।
- ভার্সন পুরোনো মনে হলে: `flutter pub upgrade --major-versions`।
