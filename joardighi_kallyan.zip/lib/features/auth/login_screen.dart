import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/err.dart';
import '../../l10n/app_localizations.dart';
import '../../providers/providers.dart';
import '../../services/auth_service.dart';

class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});
  @override
  ConsumerState<LoginScreen> createState() => _S();
}

class _S extends ConsumerState<LoginScreen> {
  final _id = TextEditingController();
  final _pw = TextEditingController();
  bool _busy = false, _hide = true;
  String? _error;

  Future<void> _go() async {
    final l = AppLocalizations.of(context)!;
    if (_id.text.trim().isEmpty || _pw.text.isEmpty) {
      setState(() => _error = l.required);
      return;
    }
    setState(() { _busy = true; _error = null; });
    try {
      await ref.read(authServiceProvider).signIn(_id.text, _pw.text);
    } on AuthException catch (e) {
      if (mounted) setState(() => _error = errText(l, e.code));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context)!;
    final cs = Theme.of(context).colorScheme;
    final lang = ref.watch(settingsProvider).locale.languageCode;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(children: [
                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton(
                    onPressed: () => ref
                        .read(settingsProvider.notifier)
                        .setLang(lang == 'bn' ? 'en' : 'bn'),
                    child: Text(lang == 'bn' ? 'English' : 'বাংলা'),
                  ),
                ),
                Image.asset('assets/logo.png', height: 96,
                    errorBuilder: (_, __, ___) =>
                        Icon(Icons.volunteer_activism, size: 80, color: cs.primary)),
                const SizedBox(height: 12),
                Text(l.appName,
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold, color: cs.primary)),
                const SizedBox(height: 6),
                Text(l.tagline,
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.bodySmall),
                const SizedBox(height: 28),
                TextField(
                  controller: _id,
                  autocorrect: false,
                  textInputAction: TextInputAction.next,
                  decoration: InputDecoration(
                      labelText: l.userId, prefixIcon: const Icon(Icons.badge_outlined)),
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: _pw,
                  obscureText: _hide,
                  onSubmitted: (_) => _go(),
                  decoration: InputDecoration(
                    labelText: l.password,
                    prefixIcon: const Icon(Icons.lock_outline),
                    suffixIcon: IconButton(
                      icon: Icon(_hide ? Icons.visibility : Icons.visibility_off),
                      onPressed: () => setState(() => _hide = !_hide),
                    ),
                  ),
                ),
                if (_error != null) ...[
                  const SizedBox(height: 12),
                  Text(_error!, style: TextStyle(color: cs.error)),
                ],
                const SizedBox(height: 20),
                FilledButton(
                  onPressed: _busy ? null : _go,
                  child: _busy
                      ? const SizedBox(
                          height: 20, width: 20,
                          child: CircularProgressIndicator(strokeWidth: 2))
                      : Text(l.login),
                ),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
