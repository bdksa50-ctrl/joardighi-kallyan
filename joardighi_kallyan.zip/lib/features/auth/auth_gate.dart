import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../l10n/app_localizations.dart';
import '../../providers/providers.dart';
import '../home/home_shell.dart';
import 'change_password_screen.dart';
import 'login_screen.dart';

class AuthGate extends ConsumerWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    const splash = Scaffold(body: Center(child: CircularProgressIndicator()));
    return ref.watch(authUserProvider).when(
          loading: () => splash,
          error: (e, _) => Scaffold(body: Center(child: Text('$e'))),
          data: (u) {
            if (u == null) return const LoginScreen();
            return ref.watch(appUserProvider).when(
                  loading: () => splash,
                  error: (e, _) => Scaffold(body: Center(child: Text('$e'))),
                  data: (a) {
                    if (a == null || !a.active) return const _NoAccess();
                    if (a.mustChangePassword) {
                      return const ChangePasswordScreen(forced: true);
                    }
                    return HomeShell(user: a);
                  },
                );
          },
        );
  }
}

class _NoAccess extends ConsumerWidget {
  const _NoAccess();
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = AppLocalizations.of(context)!;
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(l.errNoProfile, textAlign: TextAlign.center),
            const SizedBox(height: 16),
            FilledButton(
                onPressed: () => ref.read(authServiceProvider).signOut(),
                child: Text(l.logout)),
          ]),
        ),
      ),
    );
  }
}
