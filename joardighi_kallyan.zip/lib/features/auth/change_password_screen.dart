import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/err.dart';
import '../../l10n/app_localizations.dart';
import '../../providers/providers.dart';
import '../../services/auth_service.dart';

class ChangePasswordScreen extends ConsumerStatefulWidget {
  const ChangePasswordScreen({super.key, this.forced = false});
  final bool forced;
  @override
  ConsumerState<ChangePasswordScreen> createState() => _S();
}

class _S extends ConsumerState<ChangePasswordScreen> {
  final _form = GlobalKey<FormState>();
  final _a = TextEditingController();
  final _b = TextEditingController();
  bool _busy = false;
  String? _error;

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    final l = AppLocalizations.of(context)!;
    setState(() { _busy = true; _error = null; });
    try {
      await ref.read(authServiceProvider).changePassword(_a.text);
      if (!widget.forced && mounted) Navigator.pop(context);
      // forced: AuthGate reacts to mustChangePassword=false automatically
    } on AuthException catch (e) {
      if (mounted) setState(() => _error = errText(l, e.code));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context)!;
    return Scaffold(
      appBar: AppBar(
        title: Text(l.changePassword),
        automaticallyImplyLeading: !widget.forced,
        actions: [
          if (widget.forced)
            IconButton(
              tooltip: l.logout,
              icon: const Icon(Icons.logout),
              onPressed: () => ref.read(authServiceProvider).signOut(),
            ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _form,
          child: ListView(children: [
            if (widget.forced) ...[
              Text(l.changePasswordFirst),
              const SizedBox(height: 16),
            ],
            TextFormField(
              controller: _a,
              obscureText: true,
              decoration: InputDecoration(labelText: l.newPassword),
              validator: (v) => (v ?? '').length < 8 ? l.errWeak : null,
            ),
            const SizedBox(height: 14),
            TextFormField(
              controller: _b,
              obscureText: true,
              decoration: InputDecoration(labelText: l.confirmPassword),
              validator: (v) => v != _a.text ? l.passwordMismatch : null,
            ),
            if (_error != null) ...[
              const SizedBox(height: 12),
              Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
            ],
            const SizedBox(height: 20),
            FilledButton(
                onPressed: _busy ? null : _save, child: Text(l.save)),
          ]),
        ),
      ),
    );
  }
}
