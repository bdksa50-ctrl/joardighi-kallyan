import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../l10n/app_localizations.dart';
import '../../models/member.dart';
import '../../providers/providers.dart';
import '../auth/change_password_screen.dart';
import '../home/home_shell.dart' show roleLabel;

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key, required this.user});
  final AppUser user;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = AppLocalizations.of(context)!;
    final s = ref.watch(settingsProvider);
    final n = ref.read(settingsProvider.notifier);
    return ListView(padding: const EdgeInsets.all(16), children: [
      Card(
        child: ListTile(
          leading: const Icon(Icons.account_circle_outlined),
          title: Text(user.userId),
          subtitle: Text(roleLabel(l, user.role)),
        ),
      ),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(l.language),
            const SizedBox(height: 8),
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'bn', label: Text('বাংলা')),
                ButtonSegment(value: 'en', label: Text('English')),
              ],
              selected: {s.locale.languageCode},
              onSelectionChanged: (v) => n.setLang(v.first),
            ),
          ]),
        ),
      ),
      Card(
        child: SwitchListTile(
          secondary: const Icon(Icons.dark_mode_outlined),
          title: Text(l.darkMode),
          value: s.dark,
          onChanged: n.setDark,
        ),
      ),
      Card(
        child: ListTile(
          leading: const Icon(Icons.lock_reset),
          title: Text(l.changePassword),
          onTap: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const ChangePasswordScreen())),
        ),
      ),
      Card(
        child: ListTile(
          leading: const Icon(Icons.logout),
          title: Text(l.logout),
          onTap: () => ref.read(authServiceProvider).signOut(),
        ),
      ),
    ]);
  }
}
