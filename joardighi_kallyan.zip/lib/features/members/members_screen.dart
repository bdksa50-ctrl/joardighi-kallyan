import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/err.dart';
import '../../l10n/app_localizations.dart';
import '../../models/member.dart';
import '../../providers/providers.dart';
import '../../services/auth_service.dart';
import 'member_form.dart';

class MembersScreen extends ConsumerStatefulWidget {
  const MembersScreen({super.key, required this.user});
  final AppUser user;
  @override
  ConsumerState<MembersScreen> createState() => _S();
}

class _S extends ConsumerState<MembersScreen> {
  String _q = '';
  int _f = 0; // 0 all, 1 active, 2 inactive
  bool get _admin => widget.user.isAdmin;

  void _snack(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _import() async {
    final l = AppLocalizations.of(context)!;
    try {
      final n = await ref.read(memberServiceProvider).importSeed(widget.user.uid);
      if (mounted) _snack(l.importDone(n));
    } catch (_) {
      if (mounted) _snack(l.errGeneric);
    }
  }

  Future<void> _createAccount(Member m) async {
    final l = AppLocalizations.of(context)!;
    var role = Role.member;
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (c, set) => AlertDialog(
          title: Text('${l.createAccount}: ${m.nameBn}'),
          content: DropdownButtonFormField<Role>(
            value: role,
            decoration: InputDecoration(labelText: l.accountRole),
            items: [
              DropdownMenuItem(value: Role.member, child: Text(l.roleMember)),
              DropdownMenuItem(value: Role.treasurer, child: Text(l.roleTreasurer)),
            ],
            onChanged: (v) => set(() => role = v!),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: Text(l.cancel)),
            FilledButton(
                style: FilledButton.styleFrom(minimumSize: const Size(100, 40)),
                onPressed: () => Navigator.pop(c, true),
                child: Text(l.confirm)),
          ],
        ),
      ),
    );
    if (ok != true) return;
    try {
      final temp = await ref
          .read(authServiceProvider)
          .createMemberAccount(memberId: m.id, role: role);
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (c) => AlertDialog(
          title: Text(l.tempPassword),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            Text('${l.userId}: ${m.id}'),
            const SizedBox(height: 8),
            SelectableText(temp,
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Text(l.tempPasswordNote, style: Theme.of(c).textTheme.bodySmall),
          ]),
          actions: [
            TextButton(
              onPressed: () {
                Clipboard.setData(ClipboardData(text: temp));
                _snack(l.copied);
              },
              child: Text(l.copy),
            ),
            FilledButton(
                style: FilledButton.styleFrom(minimumSize: const Size(80, 40)),
                onPressed: () => Navigator.pop(c),
                child: const Text('OK')),
          ],
        ),
      );
    } on AuthException catch (e) {
      if (mounted) _snack(errText(l, e.code));
    } catch (_) {
      if (mounted) _snack(l.errGeneric);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context)!;
    final async = ref.watch(membersProvider);
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: _admin
          ? FloatingActionButton.extended(
              onPressed: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => MemberForm(user: widget.user))),
              icon: const Icon(Icons.person_add),
              label: Text(l.addMember),
            )
          : null,
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
          child: Row(children: [
            Expanded(
              child: TextField(
                onChanged: (v) => setState(() => _q = v.trim()),
                decoration: InputDecoration(
                    hintText: l.search, prefixIcon: const Icon(Icons.search), isDense: true),
              ),
            ),
            if (_admin)
              IconButton(
                tooltip: l.importSeed,
                icon: const Icon(Icons.cloud_download_outlined),
                onPressed: _import,
              ),
          ]),
        ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(children: [
            for (final (i, t) in [l.filterAll, l.filterActive, l.filterInactive].indexed)
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: ChoiceChip(
                    label: Text(t),
                    selected: _f == i,
                    onSelected: (_) => setState(() => _f = i)),
              ),
          ]),
        ),
        Expanded(
          child: async.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (e, _) => Center(child: Text('$e')),
            data: (all) {
              final q = _q.toLowerCase();
              final list = all.where((m) {
                if (_f == 1 && !m.active) return false;
                if (_f == 2 && m.active) return false;
                return q.isEmpty ||
                    m.nameBn.toLowerCase().contains(q) ||
                    (m.nameEn ?? '').toLowerCase().contains(q) ||
                    m.id.toLowerCase().contains(q);
              }).toList();
              if (list.isEmpty) return Center(child: Text(l.noMembers));
              return ListView.builder(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 88),
                itemCount: list.length,
                itemBuilder: (_, i) {
                  final m = list[i];
                  return Card(
                    child: ListTile(
                      leading: CircleAvatar(child: Text('${m.serial}')),
                      title: Text(m.nameBn),
                      subtitle: Text([
                        m.id,
                        if ((m.phone ?? '').isNotEmpty) m.phone!,
                        if (!m.active) l.filterInactive,
                      ].join(' · ')),
                      trailing: m.uid != null
                          ? Tooltip(
                              message: l.accountReady,
                              child: const Icon(Icons.check_circle, color: Colors.green))
                          : _admin && m.active
                              ? TextButton(
                                  onPressed: () => _createAccount(m),
                                  child: Text(l.createAccount))
                              : null,
                      onTap: _admin
                          ? () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => MemberForm(user: widget.user, member: m)))
                          : null,
                    ),
                  );
                },
              );
            },
          ),
        ),
      ]),
    );
  }
}
