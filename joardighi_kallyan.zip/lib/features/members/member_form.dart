import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../l10n/app_localizations.dart';
import '../../models/member.dart';
import '../../providers/providers.dart';

class MemberForm extends ConsumerStatefulWidget {
  const MemberForm({super.key, required this.user, this.member});
  final AppUser user;
  final Member? member; // null = new
  @override
  ConsumerState<MemberForm> createState() => _S();
}

class _S extends ConsumerState<MemberForm> {
  final _form = GlobalKey<FormState>();
  late final _nameBn = TextEditingController(text: widget.member?.nameBn);
  late final _nameEn = TextEditingController(text: widget.member?.nameEn);
  late final _phone = TextEditingController(text: widget.member?.phone);
  late final _start = TextEditingController(text: widget.member?.startMonth);
  late String? _country = widget.member?.country;
  late bool _active = widget.member?.active ?? true;
  bool _busy = false;

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    final l = AppLocalizations.of(context)!;
    setState(() => _busy = true);
    try {
      final svc = ref.read(memberServiceProvider);
      final old = widget.member;
      final isNew = old == null;
      var id = old?.id ?? '';
      var serial = old?.serial ?? 0;
      if (isNew) {
        final n = await svc.nextId();
        id = n.$1;
        serial = n.$2;
      }
      String? nz(String s) => s.trim().isEmpty ? null : s.trim();
      final m = Member(
        id: id,
        serial: serial,
        nameBn: _nameBn.text.trim(),
        nameEn: nz(_nameEn.text),
        phone: nz(_phone.text),
        country: _country,
        active: _active,
        startMonth: nz(_start.text),
        uid: old?.uid,
        note: old?.note,
      );
      await svc.save(m, isNew: isNew, actorUid: widget.user.uid);
      // keep login access in sync with member status
      if (!isNew && old.uid != null && old.active != _active) {
        await ref.read(authServiceProvider).setActive(old.uid!, _active);
      }
      if (mounted) Navigator.pop(context);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(l.errGeneric)));
        setState(() => _busy = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context)!;
    final isNew = widget.member == null;
    return Scaffold(
      appBar: AppBar(title: Text(isNew ? l.addMember : '${l.editMember} · ${widget.member!.id}')),
      body: Form(
        key: _form,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          TextFormField(
            controller: _nameBn,
            decoration: InputDecoration(labelText: l.nameBn),
            validator: (v) => (v ?? '').trim().isEmpty ? l.required : null,
          ),
          const SizedBox(height: 14),
          TextFormField(controller: _nameEn, decoration: InputDecoration(labelText: l.nameEn)),
          const SizedBox(height: 14),
          TextFormField(
            controller: _phone,
            keyboardType: TextInputType.phone,
            decoration: InputDecoration(labelText: l.phone),
          ),
          const SizedBox(height: 14),
          DropdownButtonFormField<String>(
            value: _country,
            decoration: InputDecoration(labelText: l.country),
            items: const [
              DropdownMenuItem(value: 'BD', child: Text('Bangladesh')),
              DropdownMenuItem(value: 'SA', child: Text('Saudi Arabia')),
              DropdownMenuItem(value: 'OTHER', child: Text('Other')),
            ],
            onChanged: (v) => setState(() => _country = v),
          ),
          const SizedBox(height: 14),
          TextFormField(
            controller: _start,
            decoration: InputDecoration(labelText: l.startMonth, helperText: l.startMonthHint, helperMaxLines: 3),
            validator: (v) {
              final s = (v ?? '').trim();
              if (s.isEmpty) return null;
              return RegExp(r'^\d{4}-(0[1-9]|1[0-2])$').hasMatch(s) ? null : l.invalidMonth;
            },
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(l.active),
            value: _active,
            onChanged: (v) => setState(() => _active = v),
          ),
          const SizedBox(height: 12),
          FilledButton(onPressed: _busy ? null : _save, child: Text(l.save)),
        ]),
      ),
    );
  }
}
