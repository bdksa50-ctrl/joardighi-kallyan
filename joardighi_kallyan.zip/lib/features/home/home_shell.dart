import 'package:flutter/material.dart';
import '../../l10n/app_localizations.dart';
import '../../models/member.dart';
import '../members/members_screen.dart';
import '../settings/settings_screen.dart';

class _Item {
  final String key;
  final IconData icon;
  final String Function(AppLocalizations) label;
  final int phase; // phase in which the real screen is built (0 = ready)
  const _Item(this.key, this.icon, this.label, this.phase);
}

final _items = <_Item>[
  _Item('home', Icons.home_outlined, (l) => l.navHome, 0),
  _Item('members', Icons.groups_outlined, (l) => l.navMembers, 0),
  _Item('chanda', Icons.payments_outlined, (l) => l.navChanda, 4),
  _Item('dues', Icons.circle, (l) => l.navDues, 4),
  _Item('investments', Icons.trending_up, (l) => l.navInvestments, 5),
  _Item('income', Icons.south_west, (l) => l.navIncome, 6),
  _Item('expenses', Icons.north_east, (l) => l.navExpenses, 6),
  _Item('projects', Icons.volunteer_activism_outlined, (l) => l.navProjects, 6),
  _Item('reports', Icons.picture_as_pdf_outlined, (l) => l.navReports, 7),
  _Item('settings', Icons.settings_outlined, (l) => l.settings, 0),
];

class HomeShell extends StatefulWidget {
  const HomeShell({super.key, required this.user});
  final AppUser user;
  @override
  State<HomeShell> createState() => _S();
}

class _S extends State<HomeShell> {
  String _key = 'home';

  List<_Item> get _visible =>
      _items.where((i) => i.key != 'members' || widget.user.isStaff).toList();

  Widget _page(AppLocalizations l, _Item it) {
    switch (it.key) {
      case 'home':
        return _Welcome(user: widget.user);
      case 'members':
        return MembersScreen(user: widget.user);
      case 'settings':
        return SettingsScreen(user: widget.user);
      default:
        return Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text(l.comingSoon(it.phase), textAlign: TextAlign.center),
          ),
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context)!;
    final cs = Theme.of(context).colorScheme;
    final cur = _visible.firstWhere((i) => i.key == _key, orElse: () => _visible.first);
    return Scaffold(
      appBar: AppBar(title: Text(cur.label(l))),
      drawer: Drawer(
        child: SafeArea(
          child: Column(children: [
            Container(
              width: double.infinity,
              color: cs.primary,
              padding: const EdgeInsets.all(20),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Icon(Icons.volunteer_activism, color: cs.onPrimary, size: 36),
                const SizedBox(height: 8),
                Text(l.appName,
                    style: TextStyle(
                        color: cs.onPrimary, fontWeight: FontWeight.bold, fontSize: 16)),
                Text(widget.user.userId, style: TextStyle(color: cs.onPrimary)),
              ]),
            ),
            Expanded(
              child: ListView(children: [
                for (final it in _visible)
                  ListTile(
                    leading: Icon(it.icon,
                        color: it.key == 'dues' ? Colors.red : null, size: it.key == 'dues' ? 16 : null),
                    title: Text(it.label(l)),
                    selected: it.key == cur.key,
                    onTap: () {
                      setState(() => _key = it.key);
                      Navigator.pop(context);
                    },
                  ),
              ]),
            ),
          ]),
        ),
      ),
      body: _page(l, cur),
    );
  }
}

class _Welcome extends StatelessWidget {
  const _Welcome({required this.user});
  final AppUser user;
  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context)!;
    final cs = Theme.of(context).colorScheme;
    return ListView(padding: const EdgeInsets.all(16), children: [
      Card(
        color: cs.primaryContainer,
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${l.welcome}, ${user.userId}',
                style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 6),
            Text(roleLabel(l, user.role)),
            const SizedBox(height: 12),
            Text(l.tagline),
          ]),
        ),
      ),
    ]);
  }
}

String roleLabel(AppLocalizations l, Role r) => switch (r) {
      Role.superAdmin => l.roleSuperAdmin,
      Role.treasurer => l.roleTreasurer,
      Role.member => l.roleMember,
    };
