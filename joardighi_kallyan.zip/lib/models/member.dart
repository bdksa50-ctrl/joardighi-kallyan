import 'package:cloud_firestore/cloud_firestore.dart';

enum Role { superAdmin, treasurer, member }

Role roleFromString(String s) => switch (s) {
      'super_admin' => Role.superAdmin,
      'treasurer' => Role.treasurer,
      _ => Role.member,
    };

String roleToString(Role r) => switch (r) {
      Role.superAdmin => 'super_admin',
      Role.treasurer => 'treasurer',
      Role.member => 'member',
    };

/// members/{memberId}  e.g. JPKS-012. Every listed entry is separate.
class Member {
  final String id;
  final int serial;
  final String nameBn;
  final String? nameEn;
  final String? phone;
  final String? country; // BD / SA ...
  final bool active;
  final String? startMonth; // 'YYYY-MM' - set by admin; dues count from here
  final String? uid;
  final String? note;

  const Member({
    required this.id,
    required this.serial,
    required this.nameBn,
    this.nameEn,
    this.phone,
    this.country,
    this.active = true,
    this.startMonth,
    this.uid,
    this.note,
  });

  factory Member.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data()!;
    return Member(
      id: d.id,
      serial: (m['serial'] ?? 0) as int,
      nameBn: m['nameBn'] ?? '',
      nameEn: m['nameEn'],
      phone: m['phone'],
      country: m['country'],
      active: m['active'] ?? true,
      startMonth: m['startMonth'],
      uid: m['uid'],
      note: m['note'],
    );
  }

  Map<String, dynamic> toMap() => {
        'serial': serial,
        'nameBn': nameBn,
        'nameEn': nameEn,
        'phone': phone,
        'country': country,
        'active': active,
        'startMonth': startMonth,
        'uid': uid,
        'note': note,
      };
}

/// users/{uid}
class AppUser {
  final String uid;
  final String userId; // login ID, e.g. JPKS-012
  final String? memberId;
  final Role role;
  final bool active;
  final bool mustChangePassword;

  const AppUser({
    required this.uid,
    required this.userId,
    required this.memberId,
    required this.role,
    required this.active,
    required this.mustChangePassword,
  });

  bool get isAdmin => role == Role.superAdmin;
  bool get isStaff => role != Role.member;

  factory AppUser.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data()!;
    return AppUser(
      uid: d.id,
      userId: m['userId'] ?? '',
      memberId: m['memberId'],
      role: roleFromString(m['role'] ?? 'member'),
      active: m['active'] ?? false,
      mustChangePassword: m['mustChangePassword'] ?? true,
    );
  }
}
