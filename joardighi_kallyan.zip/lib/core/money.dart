/// All money is stored as integer paisa (1 BDT = 100 paisa). No doubles.
class Money implements Comparable<Money> {
  final int paisa;
  const Money(this.paisa);
  static const zero = Money(0);

  /// Parses "1,500", "1500.50", "১৫০০" etc. Max 2 decimals.
  factory Money.parse(String input) {
    const bn = '০১২৩৪৫৬৭৮৯';
    var s = input.trim().replaceAll(',', '').replaceAll('৳', '');
    for (var i = 0; i < 10; i++) {
      s = s.replaceAll(bn[i], '$i');
    }
    final m = RegExp(r'^(\d+)(?:\.(\d{1,2}))?$').firstMatch(s);
    if (m == null) throw FormatException('Invalid amount: $input');
    final whole = int.parse(m.group(1)!);
    final frac = int.parse((m.group(2) ?? '0').padRight(2, '0'));
    return Money(whole * 100 + frac);
  }

  Money operator +(Money o) => Money(paisa + o.paisa);
  Money operator -(Money o) => Money(paisa - o.paisa);
  bool operator >(Money o) => paisa > o.paisa;
  bool operator <(Money o) => paisa < o.paisa;
  Money clampMin(Money min) => paisa < min.paisa ? min : this;

  @override
  int compareTo(Money o) => paisa.compareTo(o.paisa);
  @override
  bool operator ==(Object o) => o is Money && o.paisa == paisa;
  @override
  int get hashCode => paisa.hashCode;

  /// Bangladeshi digit grouping (12,34,567). [bn] uses Bangla digits.
  String format({bool bn = true, bool symbol = true}) {
    final neg = paisa < 0;
    final abs = paisa.abs();
    final whole = (abs ~/ 100).toString();
    final frac = abs % 100;
    var g = whole;
    if (whole.length > 3) {
      final head = whole.substring(0, whole.length - 3);
      final tail = whole.substring(whole.length - 3);
      final parts = <String>[];
      for (var i = head.length; i > 0; i -= 2) {
        parts.insert(0, head.substring(i - 2 < 0 ? 0 : i - 2, i));
      }
      g = '${parts.join(',')},$tail';
    }
    var out = frac == 0 ? g : '$g.${frac.toString().padLeft(2, '0')}';
    if (bn) {
      const d = '০১২৩৪৫৬৭৮৯';
      out = out.replaceAllMapped(RegExp(r'\d'), (m) => d[int.parse(m[0]!)]);
    }
    return '${neg ? '-' : ''}${symbol ? '৳' : ''}$out';
  }
}
