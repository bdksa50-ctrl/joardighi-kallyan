import '../l10n/app_localizations.dart';

String errText(AppLocalizations l, String code) => switch (code) {
      'invalid_credentials' => l.errInvalid,
      'account_disabled' => l.errDisabled,
      'network' => l.errNetwork,
      'too_many' => l.errTooMany,
      'weak_password' => l.errWeak,
      'relogin_required' => l.errRelogin,
      'no_profile' => l.errNoProfile,
      'account_exists' => l.errExists,
      _ => l.errGeneric,
    };
