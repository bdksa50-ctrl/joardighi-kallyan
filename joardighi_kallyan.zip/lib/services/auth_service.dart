import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import '../models/member.dart';

class AuthException implements Exception {
  final String code; // maps to l10n keys
  AuthException(this.code);
  @override
  String toString() => code;
}

class AuthService {
  AuthService({FirebaseAuth? auth, FirebaseFirestore? db})
      : _auth = auth ?? FirebaseAuth.instance,
        _db = db ?? FirebaseFirestore.instance;

  final FirebaseAuth _auth;
  final FirebaseFirestore _db;
  static const domain = 'joardighi.app';

  static String emailFor(String userId) =>
      '${userId.trim().toLowerCase()}@$domain';

  Stream<User?> get authChanges => _auth.authStateChanges();

  Future<AppUser> loadProfile(String uid) async {
    final d = await _db.collection('users').doc(uid).get();
    if (!d.exists) throw AuthException('no_profile');
    return AppUser.fromDoc(d);
  }

  /// Login with User ID + password.
  Future<AppUser> signIn(String userId, String password) async {
    try {
      final cred = await _auth.signInWithEmailAndPassword(
          email: emailFor(userId), password: password);
      final profile = await loadProfile(cred.user!.uid);
      if (!profile.active) {
        await _auth.signOut();
        throw AuthException('account_disabled');
      }
      return profile;
    } on FirebaseAuthException catch (e) {
      if (e.code == 'too-many-requests') throw AuthException('too_many');
      if (e.code == 'network-request-failed') throw AuthException('network');
      throw AuthException('invalid_credentials');
    }
  }

  Future<void> signOut() => _auth.signOut();

  /// Forced on first login; also used from Settings.
  Future<void> changePassword(String newPassword) async {
    if (newPassword.length < 8) throw AuthException('weak_password');
    final u = _auth.currentUser;
    if (u == null) throw AuthException('not_signed_in');
    try {
      await u.updatePassword(newPassword);
    } on FirebaseAuthException catch (e) {
      if (e.code == 'requires-recent-login') {
        throw AuthException('relogin_required');
      }
      throw AuthException('weak_password');
    }
    await _db
        .collection('users')
        .doc(u.uid)
        .update({'mustChangePassword': false});
  }

  /// Optional: lets a member attach a real email so email-based reset works.
  Future<void> linkRealEmail(String email) async {
    await _auth.currentUser!.verifyBeforeUpdateEmail(email);
  }

  /// Super Admin only. Uses a SECOND Firebase app so the admin stays logged in.
  /// Returns the temporary password (show once; it is never stored).
  Future<String> createMemberAccount({
    required String memberId,
    required Role role,
  }) async {
    final secondary = await _secondaryApp();
    final sAuth = FirebaseAuth.instanceFor(app: secondary);
    final temp = generateTempPassword();
    final UserCredential cred;
    try {
      cred = await sAuth.createUserWithEmailAndPassword(
          email: emailFor(memberId), password: temp);
    } on FirebaseAuthException catch (e) {
      if (e.code == 'email-already-in-use') {
        throw AuthException('account_exists');
      }
      rethrow;
    }
    final uid = cred.user!.uid;
    await sAuth.signOut();

    final batch = _db.batch();
    batch.set(_db.collection('users').doc(uid), {
      'userId': memberId,
      'memberId': memberId,
      'role': roleToString(role),
      'active': true,
      'mustChangePassword': true,
      'createdBy': _auth.currentUser!.uid,
      'createdAt': FieldValue.serverTimestamp(),
    });
    batch.update(_db.collection('members').doc(memberId), {'uid': uid});
    batch.set(_db.collection('audit_logs').doc(), {
      'action': 'create_account',
      'target': 'users/$uid',
      'memberId': memberId,
      'actorUid': _auth.currentUser!.uid,
      'at': FieldValue.serverTimestamp(),
    });
    await batch.commit();
    return temp;
  }

  /// Disable/enable login (profile flag; enforced by security rules + login).
  Future<void> setActive(String uid, bool active) async {
    await _db.collection('users').doc(uid).update({'active': active});
    await _db.collection('audit_logs').add({
      'action': active ? 'activate_user' : 'deactivate_user',
      'target': 'users/$uid',
      'actorUid': _auth.currentUser!.uid,
      'at': FieldValue.serverTimestamp(),
    });
  }

  Future<FirebaseApp> _secondaryApp() async {
    try {
      return Firebase.app('secondary');
    } catch (_) {
      return Firebase.initializeApp(
          name: 'secondary', options: Firebase.app().options);
    }
  }

  static String generateTempPassword([int len = 10]) {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
    final r = Random.secure();
    return List.generate(len, (_) => chars[r.nextInt(chars.length)]).join();
  }
}
