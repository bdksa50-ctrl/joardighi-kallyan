import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/services.dart';
import '../models/member.dart';

class MemberService {
  MemberService({FirebaseFirestore? db}) : _db = db ?? FirebaseFirestore.instance;
  final FirebaseFirestore _db;

  CollectionReference<Map<String, dynamic>> get _col => _db.collection('members');

  Stream<List<Member>> watchAll() => _col
      .orderBy('serial')
      .snapshots()
      .map((s) => s.docs.map(Member.fromDoc).toList());

  Future<void> _audit(String action, String target, String actor,
      [Map<String, dynamic>? extra]) {
    return _db.collection('audit_logs').add({
      'action': action,
      'target': target,
      'actorUid': actor,
      'at': FieldValue.serverTimestamp(),
      if (extra != null) ...extra,
    });
  }

  /// Adds only members whose ID does not exist yet. Never merges or overwrites.
  Future<int> importSeed(String actorUid) async {
    final raw = await rootBundle.loadString('assets/members_seed.json');
    final list = (jsonDecode(raw) as List).cast<Map<String, dynamic>>();
    final existing = (await _col.get()).docs.map((d) => d.id).toSet();
    final batch = _db.batch();
    var n = 0;
    for (final m in list) {
      final id = m['id'] as String;
      if (existing.contains(id)) continue;
      batch.set(_col.doc(id), {
        'serial': m['serial'],
        'nameBn': m['nameBn'],
        'nameEn': null,
        'phone': null,
        'country': null,
        'active': true,
        'startMonth': m['startMonth'],
        'uid': null,
        'note': null,
        'createdAt': FieldValue.serverTimestamp(),
      });
      n++;
    }
    if (n > 0) {
      await batch.commit();
      await _audit('import_members', 'members', actorUid, {'count': n});
    }
    return n;
  }

  Future<void> save(Member m, {required bool isNew, required String actorUid}) async {
    final data = m.toMap()..remove('uid');
    if (isNew) {
      await _col.doc(m.id).set({
        ...data,
        'uid': null,
        'createdAt': FieldValue.serverTimestamp(),
      });
    } else {
      await _col.doc(m.id).update({
        ...data,
        'updatedAt': FieldValue.serverTimestamp(),
      });
    }
    await _audit(isNew ? 'create_member' : 'edit_member', 'members/${m.id}', actorUid);
  }

  /// Next free ID, e.g. JPKS-059. Uses highest existing serial.
  Future<(String id, int serial)> nextId() async {
    final q = await _col.orderBy('serial', descending: true).limit(1).get();
    final next = q.docs.isEmpty ? 1 : (q.docs.first.data()['serial'] as int) + 1;
    return ('JPKS-${next.toString().padLeft(3, '0')}', next);
  }
}
