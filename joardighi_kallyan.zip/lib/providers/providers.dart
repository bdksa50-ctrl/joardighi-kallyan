import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/member.dart';
import '../services/auth_service.dart';
import '../services/member_service.dart';

final authServiceProvider = Provider((_) => AuthService());
final memberServiceProvider = Provider((_) => MemberService());

final authUserProvider = StreamProvider<User?>(
    (ref) => ref.watch(authServiceProvider).authChanges);

/// Live profile (role, active, mustChangePassword).
final appUserProvider = StreamProvider<AppUser?>((ref) {
  final u = ref.watch(authUserProvider).valueOrNull;
  if (u == null) return Stream.value(null);
  return FirebaseFirestore.instance
      .collection('users')
      .doc(u.uid)
      .snapshots()
      .map((d) => d.exists ? AppUser.fromDoc(d) : null);
});

final membersProvider = StreamProvider.autoDispose<List<Member>>(
    (ref) => ref.watch(memberServiceProvider).watchAll());

class Settings {
  final Locale locale;
  final bool dark;
  const Settings(this.locale, this.dark);
}

class SettingsNotifier extends Notifier<Settings> {
  @override
  Settings build() {
    _load();
    return const Settings(Locale('bn'), false); // Bangla default
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    state = Settings(Locale(p.getString('lang') ?? 'bn'), p.getBool('dark') ?? false);
  }

  Future<void> setLang(String code) async {
    state = Settings(Locale(code), state.dark);
    (await SharedPreferences.getInstance()).setString('lang', code);
  }

  Future<void> setDark(bool v) async {
    state = Settings(state.locale, v);
    (await SharedPreferences.getInstance()).setBool('dark', v);
  }
}

final settingsProvider =
    NotifierProvider<SettingsNotifier, Settings>(SettingsNotifier.new);
