// Fill these 5 values from Firebase Console:
// Project settings (gear) -> General -> Your apps -> Android app -> SDK setup/config.
// (Android package name must be: app.joardighi.joardighi_kallyan)
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;

class DefaultFirebaseOptions {
  static const FirebaseOptions currentPlatform = FirebaseOptions(
    apiKey: 'PASTE_API_KEY',
    appId: 'PASTE_APP_ID', // looks like 1:1234567890:android:abcdef123456
    messagingSenderId: 'PASTE_PROJECT_NUMBER',
    projectId: 'PASTE_PROJECT_ID',
    storageBucket: 'PASTE_PROJECT_ID.firebasestorage.app',
  );
}
